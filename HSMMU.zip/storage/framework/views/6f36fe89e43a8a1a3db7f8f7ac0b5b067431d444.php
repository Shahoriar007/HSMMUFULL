
<?php $__env->startSection('teacherApplications'); ?>




<head>
    <style>
        /* table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
} */
        table {
            border-collapse: collapse;
            border-spacing: 0;
            width: 100%;
            border: 1px solid #ddd;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2
        }
    </style>


</head>

<body>

    <div>
        <a href=""> Dashboard</a>
    </div>
    <br><br>

    <h2 class="text-center">Teacher Application Table</h2>



    <div style="overflow-x:auto;">
        <table>
            <tr>
                <th>Id</th>
                <th>Applicant Name</th>
                <th>Photo</th>
                <th>Position</th>
                <th>CV</th>
               

                <th colspan="2" class="text-center">Action</th>
            </tr>

            <?php $__currentLoopData = $teacherApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($application->id); ?></td>
                <td><?php echo e($application->name); ?></td>
                <td>
                    <img src="<?php echo e(url('/upload/teacher_images/'. $application->photo)); ?>" alt="">
                </td>
                <td><?php echo e($application->position); ?></td>
                <td><a href="<?php echo e(url('cvs/' . $application->cv)); ?>">Download</a></td>
              
                <!-- Details Button -->
                <td>
                    <a href="<?php echo e(url('/admin/teacher/application/details')); ?>/<?php echo e($application->id); ?>">
                        <button type="button" class="btn btn-primary">Details</button>
                    </a>
                </td>

                <!-- Approve Button -->

                <?php if($application->status==1): ?>

                <td>
                    <a href="<?php echo e(url('/admin/teacher/application/approve')); ?>/<?php echo e($application->id); ?>">
                        <button type="button" class="btn btn-success">Approved</button>
                    </a>
                </td>

                <?php elseif($application->status==0): ?>

                <td>
                    <a href="<?php echo e(url('/admin/teacher/application/approve')); ?>/<?php echo e($application->id); ?>">
                        <button type="button" class="btn btn-danger">Unapproved</button>
                    </a>
                </td>

                <?php endif; ?>

               

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <!-- Button trigger modal -->
        <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button> -->



       

    </div>

</body>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/admin/adminSection/teacher_applications.blade.php ENDPATH**/ ?>