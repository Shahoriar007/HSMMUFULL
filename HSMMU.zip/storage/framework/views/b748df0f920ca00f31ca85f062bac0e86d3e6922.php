   <!-- Start Header Top 
    ============================================= -->
   <div class="top-bar-area bg-dark text-light inline inc-border">
       <div class="container">
           <div class="row align-center">
               <div class="col-lg-12">
                   <marquee behavior="alternate" loop="infinite" direction="left" style="font-size: 30px; padding:5px 0px; color:red">
                       This site is underconstruction.
                   </marquee>
               </div>


               <div class="col-lg-7 col-md-12 left-info">
                   <div class="item-flex">
                       <ul class="list">
                           <li>
                               <i class="fas fa-phone"></i><a href="callto:+8801795122874">01795-122874</a>
                           </li>
                           <li>
                               <i class="fas fa-envelope"></i><a href="mailto:banasreeiqra@gmail.com">hsmmedu@gmail.com</a>
                           </li>
                       </ul>
                   </div>
               </div>

               <div class="col-lg-5 col-md-12 right-info">
                   <div class="item-flex">
                    <div class="login mr-3">
                        <li><a href="<?php echo e(route('login')); ?>">Student/</a></li>
                        <li><a href="<?php echo e(route('teacher.login')); ?>">Teacher</a></li>
                    </div>
                       <div class="social">
                           <?php
                           $socialMedia = App\Models\Socialmedia::get();
                           ?>
                           <ul>
                               <?php $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <li class="list-inline-item">
                                   <a href="<?php echo e($item->link); ?>" class="sbtn btn-large mx-1" title="Facebook">
                                       <?php if($item->name == "facebook"): ?>
                                       <i class="fab fa-facebook-f"></i>
                                       <?php elseif($item->name == "instagram"): ?>
                                       <i class="fab fa-instagram"></i>
                                       <?php elseif($item->name == "pinterest"): ?>
                                       <i class="fab fa-pinterest-p"></i>
                                       <?php elseif($item->name == "twitter"): ?>
                                       <i class="fab fa-twitter"></i>
                                       <?php elseif($item->name == "linkedin"): ?>
                                       <i class="fab fa-linkedin-in"></i>
                                       <?php endif; ?>
                                   </a>
                               </li>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                       </div>
                   </div>
               </div>

           </div>
       </div>
   </div>
   <!-- End Header Top -->

   <!-- Header 
    ============================================= -->
   <header id="home">

       <!-- Start Navigation -->
       <nav class="navbar navbar-default attr-border navbar-sticky dark bootsnav header-back">
           <div class="container-full">
               <!-- Start Atribute Navigation -->
               <div class="attr-nav">
                   <form action="#">
                       <input type="text" placeholder="Search" class="form-control" name="text">
                       <button type="submit">
                           <i class="fa fa-search"></i>
                       </button>
                   </form>
               </div>
               <!-- End Atribute Navigation -->

               <!-- Start Header Navigation -->
               <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                       <i class="fa fa-bars"></i>
                   </button>
                   <?php
                   $logo = App\Models\Logo::get()->last();
                   ?>
                   <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                       <img src="<?php echo e(url('photos/'.$logo->image)); ?>" class="logo" alt="Logo">
                   </a>

               </div>
               <!-- End Header Navigation -->

               <!-- Collect the nav links, forms, and other content for toggling -->
               <div class="collapse navbar-collapse " id="navbar-menu">
                   <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

                       <?php
                       $navItems = App\Models\Navbar::all();
                       ?>
                       <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if($nav->status == "enable"): ?>
                       <?php if($nav->title == "Academics"): ?>
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">Academics</a>
                           <ul class="dropdown-menu">
                               <?php
                               $catagories = App\Models\Blogcatagory::all();
                               ?>
                               <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($catagory->status == "enable"): ?>
                               <li><a href="<?php echo e('/academic/blog/'.$catagory->id); ?>" class="site-nav"><?php echo e($catagory->catagoryName); ?></a></li>
                               <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           </ul>
                       </li>
                       <?php elseif($nav->title == "About"): ?>
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">About</a>
                           <ul class="dropdown-menu">
                               <li><a href="<?php echo e(route('ourTeam')); ?>">Our Honorable teachers</a></li>
                               <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                               <li><a href="<?php echo e(route('aim')); ?>">Our Aim</a></li>
                               <li><a href="<?php echo e(route('management_message')); ?>">management message</a></li>

                           </ul>
                       </li>
                       <?php elseif($nav->title == "Media"): ?>
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">Media</a>
                           <ul class="dropdown-menu">
                               <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                               
                               <!-- <li><a href="magazine.html">magazine</a></li> -->
                           </ul>
                       </li>
                       <?php else: ?>
                       <li>
                           <a href="<?php echo e($nav->url); ?>"><?php echo e($nav->title); ?></a>
                       </li>
                       <?php endif; ?>
                       <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                   </ul>

               </div>
               <!-- /.navbar-collapse -->
           </div>

       </nav>
       <!-- End Navigation -->

   </header>
   <!-- End Header --><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/user/userNavbar.blade.php ENDPATH**/ ?>