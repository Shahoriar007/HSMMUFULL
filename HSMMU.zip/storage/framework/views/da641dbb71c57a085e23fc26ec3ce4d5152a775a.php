
                <!----------------------------------------------- Body Part End ---------------------------------------------->
                


               
                </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->

  

  
</body><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/teacher/teacherFooter.blade.php ENDPATH**/ ?>