
                <!----------------------------------------------- Body Part End ---------------------------------------------->
                


               
                </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->

  

  
</body><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/admin/adminFooter.blade.php ENDPATH**/ ?>