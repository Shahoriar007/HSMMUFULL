
                <!----------------------------------------------- Body Part End ---------------------------------------------->
                


               
                </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->

  

  
</body><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\school_management-v1\hsmm\laravel_Breeze_MultiAuth-48afd2e0b99bda872f7a0f3f0b9961d3cb8e5c94\resources\views/admin/adminFooter.blade.php ENDPATH**/ ?>